import React, {useState} from 'react';
import {Box, Typography, List} from '@mui/material';
import AddTask from './AddTask';
import TodoCard from './TodoCard.tsx';
import {Task} from "./types.ts";

const TaskList: React.FC = () => {
    const [tasks, setTasks] = useState<Task[]>([]);

    const addTask = (newTask: Task): void => setTasks([...tasks, newTask]);
    const deleteTask = (id: number): void =>
        setTasks(tasks.filter((task) => task.id !== id));
    const toggleComplete = (id: number): void =>
        setTasks(
            tasks.map((task) =>
                task.id === id ? {...task, completed: !task.completed} : task
            )
        );

    return (
        <Box sx={{padding: 4}}>
            <Typography variant="h4" gutterBottom>
                To-Do List
            </Typography>
            <AddTask addTask={addTask}/>
            <List>
                {tasks.map((task) => (
                    <TodoCard
                        key={task.id}
                        task={task}
                        deleteTask={deleteTask}
                        toggleComplete={toggleComplete}
                    />
                ))}
            </List>
        </Box>
    );
};

export default TaskList;
