import React from 'react';
import {ListItem, Checkbox, IconButton, Typography} from '@mui/material';
import DeleteIcon from '@mui/icons-material/Delete';
import {Task} from "./types.ts";


interface TodoCardProps {
    task: Task;
    deleteTask: (id: number) => void;
    toggleComplete: (id: number) => void;
}

const TodoCard: React.FC<TodoCardProps> = ({
                                               task,
                                               deleteTask,
                                               toggleComplete,
                                           }) => (
    <ListItem
        secondaryAction={
            <IconButton edge="end" onClick={() => deleteTask(task.id)}>
                <DeleteIcon/>
            </IconButton>
        }
    >
        <Checkbox
            checked={task.completed}
            onChange={() => toggleComplete(task.id)}
        />
        <Typography
            variant="body1"
            sx={{textDecoration: task.completed ? 'line-through' : 'none'}}
        >
            {task.name}
        </Typography>
    </ListItem>
);

export default TodoCard;
