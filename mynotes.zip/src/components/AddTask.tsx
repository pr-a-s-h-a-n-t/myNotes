import React, {useState} from 'react';
import {TextField, Button, Box} from '@mui/material';
import {Task} from "./types.ts";

interface AddTaskProps {
    addTask: (task: Task) => void;
}

const AddTask: React.FC<AddTaskProps> = ({addTask}) => {
    const [taskName, setTaskName] = useState<string>('');

    const handleSubmit = (): void => {
        if (taskName.trim()) {
            addTask({id: Date.now(), name: taskName, completed: false});
            setTaskName('');
        }
    };

    return (
        <Box sx={{display: 'flex', gap: 2, marginBottom: 2}}>
            <TextField
                label="New Task"
                variant="outlined"
                fullWidth
                value={taskName}
                onChange={(e) => setTaskName(e.target.value)}
            />
            <Button variant="contained" onClick={handleSubmit}>
                Add
            </Button>
        </Box>
    );
};

export default AddTask;
