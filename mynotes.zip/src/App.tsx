import React from 'react'
import './App.css'
import {CssBaseline} from "@mui/material";
import Todos from "./components/Todos.tsx";

function App() {
    return (
        <React.Fragment>
            <CssBaseline/>
            <Todos/>
        </React.Fragment>
    )
}

export default App
